function togglePaste() {
    var elm = $('paste');
    if (elm.style.display == 'none') {
        new Effect.BlindDown('paste', { duration: 0.3 });
    } else {
        new Effect.SwitchOff('paste', { duration: 0.3 });
    }
    return false;
}

function toggleReply() {
    $('reply').toggle();
    return false;
}

function toggleArea(name) {
    var elm = $(name || 'code');
    elm.rows = (elm.rows == 15) ? 30 : 15;
    return false;
}

function toggleView(id) {
    var plain = $('plainCode' + id);
    if (plain.style.display == 'none') {
        plain.value = $('codeContent' + id).innerHTML.stripTags().replace(/&nbsp;/g, ' ').unescapeHTML().strip();

    }
    $('plainCode' + id).toggle();
    $('colorCode' + id).toggle();
    return false;

}
<?php
include 'mysql.php';
$id = isset($_POST['parent_id']) ? (int)$_POST['parent_id'] : 0;
if (isset($_POST['name'])) {
    setcookie('govnoname', $_POST['name'], time() + 60*60*24*200);
}
$name = isset($_POST['name']) ? mysql_real_escape_string($_POST['name']) : '';
$code = isset($_POST['code']) ? mysql_real_escape_string($_POST['code']) : '';
$langs = array('php', 'css', 'html4strict', 'ini', 'javascript', 'mysql', 'sql', 'smarty', 'xml', 'bash', 'apache', 'python', 'plain');
if (!isset($_POST['lang']) || !in_array($_POST['lang'], $langs)) {
    $_POST['lang'] = 'php';
}
$lang = $_POST['lang'];
$parent_id = 0;
if ($id) {
    $q = mysql_query('SELECT `language` FROM `pastebin` WHERE `pastebin_id` = ' . $id);
    if ($q && $result = mysql_fetch_assoc($q)) {
        $parent_id = $id;
        $lang = $result['language'];
    }
}
$q = "INSERT INTO `pastebin` (`parent_id`, `name`, `description`,`ip`,`language`,`created`) VALUES (" . $parent_id . ", '" . $name . "', '" . $code . "', '" . $_SERVER['REMOTE_ADDR'] . "', '" . $lang . "', NOW())";
if ($code && mysql_query($q)) {
    header('Location: ./' . ($parent_id ? $parent_id : mysql_insert_id()));
} else {
    header('Location: ./');
}

exit;
?>
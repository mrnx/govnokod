<?php
mysql_connect('localhost', 'root', '');
mysql_selectdb('govnokod');
mysql_query('SET NAMES utf8');
?>
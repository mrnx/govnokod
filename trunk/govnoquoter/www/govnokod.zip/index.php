<?php
$style = isset($_GET['style']) ? '-' . $_GET['style'] : '';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
error_reporting(E_ALL & ~E_NOTICE);
include_once 'geshi/geshi.php';
include_once('mysql.php');
$query = mysql_query("SELECT *, DATE_FORMAT(`created`, '%d %M %Y %H:%i:%s') AS `date` FROM `pastebin` WHERE `pastebin_id` = " . $id);
$valid = false;
if ($query) {
    $data = mysql_fetch_assoc($query);
    if (!empty($data)) {
        $source = $data['description'];
        $lines = substr_count($source, "\n");
        $lines = $lines < 1 ? 1 : $lines + 1;
        if ($data['language'] == 'plain') {
            $code = '<pre>' . htmlspecialchars($source) . '</pre>';
        } else {
            $geshi = new GeSHi($source, $data['language']);
            $code = $geshi->parse_code();
        }
        if (empty($data['name'])) {
            $data['name'] = 'unknown';
        }

        if ($_SERVER['REMOTE_ADDR'] != $data['ip']) {
            mysql_query("UPDATE `pastebin` SET `views`=`views`+1 WHERE `pastebin_id` = " . $id);
            $data['views']++;
        }

        $valid = true;
    }
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <title>ГОВНОБИН</title>
        <script src="./prototype.js" type="text/javascript"></script>
        <script src="./effects.js"type="text/javascript"></script>
        <script src="./paste.js"type="text/javascript"></script>
        <link rel="shortcut icon"href="./favicon.ico">
        <link rel="stylesheet" type="text/css" href="./styles.css">
    </head>
<body>
<div class="header">
    <div class="logo">
    <a href="/"><img src="./logo2<?php echo $style?>.gif" alt="" style="border: 0;"></a>
    </div>
    <div class="paste_link">
    <a href="#" onclick="return togglePaste();">Накласть говнокод</a>
    </div>
</div>

<div id="paste" style="display: none;">
    <span>Накласть говнокод</span>
    <form action="add.php" method="post">
    <table border="0" cellpadding="1" cellspacing="5">
        <tr>
            <td>Имя</td>
            <td><input type="text" name="name" size="30" value="<?php if (!empty($_COOKIE['govnoname'])) echo htmlspecialchars($_COOKIE['govnoname']); ?>"></td>
        </tr>
        <tr>
            <td>Язык</td>
            <td><select name="lang">
            <option value="php">PHP</option>
            <option value="mysql">MySQL</option>
            <option value="sql">SQL</option>
            <option value="html4strict">HTML</option>
            <option value="javascript">JavaScript</option>
            <option value="xml">XML</option>
            <option value="apache">Apache</option>
            <option value="smarty">Smarty</option>
            <option value="bash">Bash</option>
            <option value="python">Python</option>
            <option value="ini">INI</option>
            <option value="css">CSS</option>
            <option value="plain">Plain Text</option>
            </select></td>
        </tr>
        <tr>
            <td valign="top">Код</td>
            <td><textarea rows="15" cols="50" name="code" id="code"></textarea></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td rowspan="2">
            <div class="leftArea"><input id="submit" type="submit" value="Готово"></div>
            <div class="rightArea">
            <a href="#" onclick="return toggleArea();" class="helperLink">Мало места</a>
            </div></td>
        </tr>
    </table>
    </form>
    <div class="end hide"><a href="#" onclick="return togglePaste();">hide</a></div>
</div>
<!--div id="content">
    <p>Welcome to apache</p>
</div-->
<div class="clear"></div>
<?php if ($valid && $data['views'] < 1) { ?>
<div class="notice">Ссылка на ваш код: <a href="http://www.govnokod.com/<?php echo $data['pastebin_id']?>">http://www.govnokod.com/<?php echo $data['pastebin_id']?></a></div>
<?php } ?>
<div id="content">
<?php if ($valid) { ?>
    <div class="rightArea"><a href="#" class="helperLink" onclick="return toggleView(<?php echo $id; ?>);">plain/html</a></div>
    <div class="author">Автор: <?php echo htmlspecialchars($data['name']) . ', ' . $data['date'] ?>, просмотрено раз: <?php echo (int)$data['views'] ?></div>

    <table id="colorCode<?php echo $id; ?>" class="colorCode" cellpadding="3" cellspacing="0" border="0">
        <tr>
            <td class="line" valign="top"><pre><?php for($i = 1; $i <= $lines; $i++) { echo " "; printf('%03d', $i ); echo "\r\n"; } ?></pre></td>
            <td valign="top"><div class="codeContent" id="codeContent<?php echo $id; ?>"><?php echo $code; ?></div></td>
        </tr>
    </table>

    <textarea id="plainCode<?php echo $id; ?>" cols="30" rows="15" style="width: 100%; display: none;"></textarea>
    <div><a href="#" class="helperLink" onclick="return toggleReply();">Ответить</a></div>
    <div id="reply" style="display: none;">
    <span>Дать ответ говнокоду</span>
    <form action="add.php" method="post">

    <table border="0" cellpadding="1" cellspacing="5">
        <tr>
            <td>Имя</td>
            <td><input type="text" name="name" size="30" value="<?php if (!empty($_COOKIE['govnoname'])) echo htmlspecialchars($_COOKIE['govnoname']); ?>"></td>
        </tr>
        <tr>
            <td valign="top">Код</td>
            <td><textarea rows="15" cols="50" name="code" id="replycode"></textarea></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td rowspan="2">
            <div class="leftArea"><input type="hidden" name="parent_id" value="<?php echo $id; ?>"><input id="submitreply" type="submit" value="Готово"></div>
            <div class="rightArea">
            <a href="#" onclick="return toggleArea('replycode');" class="helperLink">Мало места</a>
            </div></td>
        </tr>
    </table>
    </form>
    <div class="end hide"><a href="#" onclick="return toggleReply();">hide</a></div>
    </div>
    <?php
        $query = mysql_query("SELECT *,  DATE_FORMAT(`created`, '%d/%m/%y %H:%i') AS `date` FROM `pastebin` WHERE `parent_id` = " . $id . " ORDER BY `pastebin_id`");
        if (mysql_num_rows($query)) {
            echo "<h3>Ответы:</h3>";
        }
        while ($data = mysql_fetch_array($query)) {
            $source = $data['description'];
            $pid = $data['pastebin_id'];
            $lines = substr_count($source, "\n");
            $lines = $lines < 1 ? 1 : $lines + 1;
            if ($data['language'] == 'plain') {
                $code = '<pre>' . htmlspecialchars($source) . '</pre>';
            } else {
                $geshi = new GeSHi($source, $data['language']);
                $code = $geshi->parse_code();
            }
            if (empty($data['name'])) {
                $data['name'] = 'unknown';
            }
        ?>
                <div class="rightArea"><a href="#" class="helperLink" onclick="return toggleView(<?php echo $pid; ?>);">plain/html</a></div>
                <div class="author">Автор: <?php echo htmlspecialchars($data['name']) . ', ' . $data['date'] ?></div>

                <table id="colorCode<?php echo $pid; ?>" class="colorCode" cellpadding="3" cellspacing="0" border="0">
                    <tr>
                        <td class="line" valign="top"><pre><?php for($i = 1; $i <= $lines; $i++) { echo " "; printf('%03d', $i ); echo "\r\n"; } ?></pre></td>
                        <td valign="top"><div class="codeContent" id="codeContent<?php echo $pid; ?>"><?php echo $code; ?></div></td>
                    </tr>
                </table>
                <textarea id="plainCode<?php echo $pid; ?>" cols="30" rows="15" style="width: 100%; display: none;"></textarea>
                <br>
    <?php
        }
    ?>
<?php } else { ?>
<h2>Добро пожаловать!</h2>
Чтобы опубликовать свой код надо нажать сверху "Накласть говнокод".
<h3>Последние 20 публикаций</h3>
<?php
$query = mysql_query("SELECT *,  DATE_FORMAT(`created`, '%d/%m/%y %H:%i') AS `date` FROM `pastebin` ORDER BY `pastebin_id` DESC LIMIT 20");
while ($row = mysql_fetch_array($query)) {
    echo '<div class="author">' . $row['date'] . ', <a class="last" href="/' . $row['pastebin_id'] . '">' . htmlspecialchars($row['name']) . '</a> (';
    if (empty($row['parent_id'])) {
        echo $row['language'] . ': ' . htmlspecialchars(substr($row['description'],0, 46)) . '...';
    } else {
        echo 'ответ на код <a class="last" href="' . $row['parent_id'] . '">' . $row['parent_id'] . '</a>';
    }
    echo ')</div>';
}
?>
<?php } ?>
</div>
<div class="end copy"><?php echo date('Y') ?> &copy; govnokod.com</div>
</body>
</html>